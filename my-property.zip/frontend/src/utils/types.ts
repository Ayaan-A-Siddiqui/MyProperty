export interface InvestorBenefit {
  title: string;
  description: string;
  icon?: string;
}

export interface HowItWorksStep {
  title: string;
  description: string;
  image?: string;
  iconClass?: string;
}
