import { useState, useEffect } from 'react';
import { toast } from 'sonner';

// Mock wallet types
export type WalletType = 'algorand' | 'myalgo' | 'pera';

export interface AlgorandAccount {
  address: string;
  name: string;
  balance: number; // In Algos
  tokens: TokenBalance[];
}

export interface TokenBalance {
  tokenId: string;
  tokenSymbol: string;
  amount: number;
}

export interface Transaction {
  id: string;
  type: 'buy' | 'sell' | 'transfer' | 'dividend';
  tokenId: string;
  tokenSymbol: string;
  amount: number;
  price: number;
  total: number;
  sender: string;
  recipient: string;
  status: 'pending' | 'confirmed' | 'failed';
  timestamp: Date;
  confirmations: number;
  blockNumber?: number;
  fee: number;
}

export interface TransactionRequest {
  type: 'buy' | 'sell' | 'transfer';
  tokenId: string;
  tokenSymbol: string;
  amount: number;
  price: number;
  recipient?: string;
}

// Pre-defined mock accounts
const MOCK_ACCOUNTS: AlgorandAccount[] = [
  {
    address: 'ALGO123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
    name: 'Main Wallet',
    balance: 5000,
    tokens: [
      { tokenId: 'token1', tokenSymbol: 'SKYT', amount: 100 },
      { tokenId: 'token2', tokenSymbol: 'WRES', amount: 250 },
      { tokenId: 'token4', tokenSymbol: 'INCM', amount: 75 },
    ]
  },
  {
    address: 'ALGO987654321ZYXWVUTSRQPONMLKJIHGFEDCBA987654',
    name: 'Investment Wallet',
    balance: 2500,
    tokens: [
      { tokenId: 'token3', tokenSymbol: 'WFML', amount: 150 },
      { tokenId: 'token5', tokenSymbol: 'HLCT', amount: 50 },
    ]
  }
];

// Mock transaction history
const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx1',
    type: 'buy',
    tokenId: 'token1',
    tokenSymbol: 'SKYT',
    amount: 50,
    price: 13.45,
    total: 672.5,
    sender: 'EXCHANGE',
    recipient: 'ALGO123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
    status: 'confirmed',
    timestamp: new Date(Date.now() - 86400000 * 2), // 2 days ago
    confirmations: 150,
    blockNumber: 8761234,
    fee: 0.002
  },
  {
    id: 'tx2',
    type: 'buy',
    tokenId: 'token2',
    tokenSymbol: 'WRES',
    amount: 100,
    price: 8.12,
    total: 812,
    sender: 'EXCHANGE',
    recipient: 'ALGO123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
    status: 'confirmed',
    timestamp: new Date(Date.now() - 86400000 * 5), // 5 days ago
    confirmations: 380,
    blockNumber: 8759876,
    fee: 0.002
  },
  {
    id: 'tx3',
    type: 'sell',
    tokenId: 'token1',
    tokenSymbol: 'SKYT',
    amount: 25,
    price: 14.25,
    total: 356.25,
    sender: 'ALGO123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
    recipient: 'EXCHANGE',
    status: 'confirmed',
    timestamp: new Date(Date.now() - 86400000), // 1 day ago
    confirmations: 72,
    blockNumber: 8762456,
    fee: 0.002
  },
  {
    id: 'tx4',
    type: 'dividend',
    tokenId: 'token2',
    tokenSymbol: 'WRES',
    amount: 250,
    price: 0.05,
    total: 12.5,
    sender: 'WRES_TREASURY',
    recipient: 'ALGO123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ123456',
    status: 'confirmed',
    timestamp: new Date(Date.now() - 86400000 / 2), // 12 hours ago
    confirmations: 36,
    blockNumber: 8763111,
    fee: 0
  },
];

// Generate a random string of specified length
const generateRandomString = (length: number): string => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

// Generate a transaction ID
const generateTransactionId = (): string => {
  return `TX${Date.now().toString(36)}${generateRandomString(8)}`;
};

// Calculate current network fee (simulated)
const calculateNetworkFee = (): number => {
  // Random fee between 0.001 and 0.004 Algos
  return 0.001 + Math.random() * 0.003;
};

// Generate a random block number
const generateBlockNumber = (): number => {
  // Current simulated block height is around 8.7 million
  return 8760000 + Math.floor(Math.random() * 10000);
};

// Simulate connection delay
const simulateNetworkDelay = async (minMs = 500, maxMs = 2000): Promise<void> => {
  const delay = minMs + Math.random() * (maxMs - minMs);
  return new Promise(resolve => setTimeout(resolve, delay));
};

// Blockchain node status (simulated)
export const getNetworkStatus = async (): Promise<{
  connected: boolean;
  currentRound: number;
  status: string;
  tps: number;
}> => {
  await simulateNetworkDelay(100, 300);
  
  // 95% chance of being online
  const isOnline = Math.random() < 0.95;
  
  return {
    connected: isOnline,
    currentRound: 8760000 + Math.floor(Math.random() * 10000),
    status: isOnline ? 'online' : 'experiencing issues',
    tps: 5 + Math.floor(Math.random() * 10) // Transactions per second
  };
};

// Hook to get and monitor wallet connection
export const useWalletConnection = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [accounts, setAccounts] = useState<AlgorandAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<AlgorandAccount | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  // Connect wallet - simulated
  const connect = async (walletType: WalletType): Promise<boolean> => {
    setIsConnecting(true);
    
    try {
      // Simulate network delay
      await simulateNetworkDelay();
      
      // 90% chance of successful connection
      const connectionSuccess = Math.random() < 0.9;
      
      if (!connectionSuccess) {
        throw new Error('Failed to connect wallet. Please try again.');
      }
      
      // Set accounts and transactions
      setAccounts(MOCK_ACCOUNTS);
      setSelectedAccount(MOCK_ACCOUNTS[0]);
      setTransactions(MOCK_TRANSACTIONS);
      setIsConnected(true);
      
      // Show success toast
      toast.success('Wallet Connected', {
        description: `Connected to ${MOCK_ACCOUNTS[0].name}`
      });
      
      return true;
    } catch (error: any) {
      console.error('Wallet connection error:', error);
      toast.error(error.message || 'Failed to connect wallet');
      return false;
    } finally {
      setIsConnecting(false);
    }
  };
  
  // Disconnect wallet
  const disconnect = async (): Promise<void> => {
    await simulateNetworkDelay(300, 800);
    setIsConnected(false);
    setAccounts([]);
    setSelectedAccount(null);
    setTransactions([]);
    toast.info('Wallet disconnected');
  };
  
  // Switch selected account
  const switchAccount = (accountAddress: string): void => {
    const account = accounts.find(acc => acc.address === accountAddress);
    if (account) {
      setSelectedAccount(account);
      toast.success(`Switched to ${account.name}`);
    }
  };
  
  // Submit a transaction
  const submitTransaction = async (txRequest: TransactionRequest): Promise<Transaction | null> => {
    if (!selectedAccount) {
      toast.error('No wallet connected');
      return null;
    }
    
    const recipient = txRequest.type === 'sell' ? 'EXCHANGE' : selectedAccount.address;
    const sender = txRequest.type === 'buy' ? 'EXCHANGE' : selectedAccount.address;
    
    // Create a new transaction
    const newTransaction: Transaction = {
      id: generateTransactionId(),
      type: txRequest.type,
      tokenId: txRequest.tokenId,
      tokenSymbol: txRequest.tokenSymbol,
      amount: txRequest.amount,
      price: txRequest.price,
      total: txRequest.amount * txRequest.price,
      sender,
      recipient: txRequest.recipient || recipient,
      status: 'pending',
      timestamp: new Date(),
      confirmations: 0,
      fee: calculateNetworkFee()
    };
    
    // Add to transactions list
    setTransactions(prev => [newTransaction, ...prev]);
    
    // Show pending toast
    toast.loading('Transaction Submitted', {
      id: newTransaction.id,
      description: `${txRequest.amount} ${txRequest.tokenSymbol} ${txRequest.type === 'buy' ? 'purchase' : 'sale'} is pending`
    });
    
    // Simulate transaction processing
    await simulateNetworkDelay(2000, 5000);
    
    // 95% chance of successful transaction
    const isSuccessful = Math.random() < 0.95;
    
    // Update transaction status
    setTransactions(prev => prev.map(tx => {
      if (tx.id === newTransaction.id) {
        return {
          ...tx,
          status: isSuccessful ? 'confirmed' : 'failed',
          confirmations: isSuccessful ? 1 : 0,
          blockNumber: isSuccessful ? generateBlockNumber() : undefined
        };
      }
      return tx;
    }));
    
    // Update account balances if successful
    if (isSuccessful) {
      // Update Algo balance for buy/sell
      if (txRequest.type === 'buy') {
        setAccounts(prev => prev.map(acc => {
          if (acc.address === selectedAccount.address) {
            return {
              ...acc,
              balance: acc.balance - txRequest.amount * txRequest.price - newTransaction.fee,
              tokens: updateTokenBalance(acc.tokens, txRequest.tokenId, txRequest.tokenSymbol, txRequest.amount)
            };
          }
          return acc;
        }));
      } else if (txRequest.type === 'sell') {
        setAccounts(prev => prev.map(acc => {
          if (acc.address === selectedAccount.address) {
            return {
              ...acc,
              balance: acc.balance + txRequest.amount * txRequest.price - newTransaction.fee,
              tokens: updateTokenBalance(acc.tokens, txRequest.tokenId, txRequest.tokenSymbol, -txRequest.amount)
            };
          }
          return acc;
        }));
      }
      
      // Update selected account
      setSelectedAccount(prev => {
        if (!prev) return null;
        
        if (txRequest.type === 'buy') {
          return {
            ...prev,
            balance: prev.balance - txRequest.amount * txRequest.price - newTransaction.fee,
            tokens: updateTokenBalance(prev.tokens, txRequest.tokenId, txRequest.tokenSymbol, txRequest.amount)
          };
        } else if (txRequest.type === 'sell') {
          return {
            ...prev,
            balance: prev.balance + txRequest.amount * txRequest.price - newTransaction.fee,
            tokens: updateTokenBalance(prev.tokens, txRequest.tokenId, txRequest.tokenSymbol, -txRequest.amount)
          };
        }
        
        return prev;
      });
      
      // Show success toast
      toast.success('Transaction Confirmed', {
        id: newTransaction.id,
        description: `${txRequest.amount} ${txRequest.tokenSymbol} ${txRequest.type === 'buy' ? 'purchased' : 'sold'} successfully`
      });
      
      // Return the updated transaction
      return {
        ...newTransaction,
        status: 'confirmed',
        confirmations: 1,
        blockNumber: generateBlockNumber()
      };
    } else {
      // Show error toast
      toast.error('Transaction Failed', {
        id: newTransaction.id,
        description: `Failed to ${txRequest.type} ${txRequest.amount} ${txRequest.tokenSymbol}`
      });
      
      return {
        ...newTransaction,
        status: 'failed',
        confirmations: 0
      };
    }
  };
  
  // Update token balance helper
  const updateTokenBalance = (tokens: TokenBalance[], tokenId: string, tokenSymbol: string, amountChange: number): TokenBalance[] => {
    const existingToken = tokens.find(t => t.tokenId === tokenId);
    
    if (existingToken) {
      // Update existing token
      return tokens.map(t => {
        if (t.tokenId === tokenId) {
          return { ...t, amount: Math.max(0, t.amount + amountChange) };
        }
        return t;
      });
    } else if (amountChange > 0) {
      // Add new token
      return [...tokens, { tokenId, tokenSymbol, amount: amountChange }];
    }
    
    return tokens;
  };
  
  // Simulate transaction confirmations increasing over time
  useEffect(() => {
    if (!isConnected || transactions.length === 0) return;
    
    const confirmationInterval = setInterval(() => {
      setTransactions(prev => prev.map(tx => {
        if (tx.status === 'confirmed' && tx.confirmations < 200) {
          return { ...tx, confirmations: tx.confirmations + Math.floor(Math.random() * 3) + 1 };
        }
        return tx;
      }));
    }, 30000); // Update every 30 seconds
    
    return () => clearInterval(confirmationInterval);
  }, [isConnected, transactions]);
  
  return {
    isConnecting,
    isConnected,
    accounts,
    selectedAccount,
    transactions,
    connect,
    disconnect,
    switchAccount,
    submitTransaction
  };
};

// Network status hook
export const useNetworkStatus = () => {
  const [status, setStatus] = useState<{
    connected: boolean;
    currentRound: number;
    status: string;
    tps: number;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch initial status
  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const networkStatus = await getNetworkStatus();
        setStatus(networkStatus);
      } catch (error) {
        console.error('Failed to fetch network status:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchStatus();
    
    // Poll for updates
    const interval = setInterval(async () => {
      try {
        const networkStatus = await getNetworkStatus();
        setStatus(networkStatus);
      } catch (error) {
        console.error('Failed to update network status:', error);
      }
    }, 15000); // Every 15 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  return { status, isLoading };
};