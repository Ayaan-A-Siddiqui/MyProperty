export const sectionClasses = {
  base: "py-16 md:py-24",
  container: "container mx-auto px-4",
  heading: "text-3xl md:text-4xl font-bold mb-6 md:mb-10 tracking-tight",
  subheading: "text-xl text-muted-foreground max-w-3xl mb-12",
  card: "relative bg-card hover:bg-card/80 transition-colors duration-200 rounded-lg overflow-hidden border border-border/40 p-6",
};

export const gradientText = "bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-blue-300";
