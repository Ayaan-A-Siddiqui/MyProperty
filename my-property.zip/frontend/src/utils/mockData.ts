// Mock token price history data generator
const generatePriceHistory = (basePrice: number, volatility: number, days: number) => {
  const history: { date: string; price: number }[] = [];
  let currentPrice = basePrice;
  
  const now = new Date();
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Random price movement based on volatility
    const change = (Math.random() - 0.5) * volatility * currentPrice;
    currentPrice = Math.max(0.01, currentPrice + change);
    
    history.push({
      date: date.toISOString().split('T')[0],
      price: parseFloat(currentPrice.toFixed(2))
    });
  }
  
  return history;
};

// Generate random volume data
const generateVolumeData = (days: number, avgVolume: number) => {
  const volumes: { date: string; volume: number }[] = [];
  
  const now = new Date();
  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Random volume with some spikes
    const isSpike = Math.random() > 0.8;
    const volume = isSpike ? 
      avgVolume * (1 + Math.random() * 2) : 
      avgVolume * (0.5 + Math.random());
    
    volumes.push({
      date: date.toISOString().split('T')[0],
      volume: Math.round(volume)
    });
  }
  
  return volumes;
};

export interface Token {
  id: string;
  propertyName: string;
  tokenSymbol: string;
  location: string;
  propertyType: string;
  currentPrice: number;
  priceChangePercent: number;
  volume24h: number;
  marketCap: number;
  annualYield: number;
  totalSupply: number;
  availableSupply: number;
  daysListed: number;
  priceHistory: { date: string; price: number }[];
  volumeHistory: { date: string; volume: number }[];
  propertyImage: string;
  propertyDescription: string;
}

// Mock tokens data
export const mockTokens: Token[] = [
  {
    id: "token1",
    propertyName: "Skyline Tower",
    tokenSymbol: "SKYT",
    location: "New York, NY",
    propertyType: "Commercial Office",
    currentPrice: 14.85,
    priceChangePercent: 2.75,
    volume24h: 32560,
    marketCap: 7425000,
    annualYield: 6.2,
    totalSupply: 500000,
    availableSupply: 468250,
    daysListed: 124,
    priceHistory: generatePriceHistory(12.50, 0.02, 90),
    volumeHistory: generateVolumeData(90, 25000),
    propertyImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab",
    propertyDescription: "Premium office space in downtown Manhattan with A-grade tenants and long-term leases."
  },
  {
    id: "token2",
    propertyName: "Waterfront Residences",
    tokenSymbol: "WRES",
    location: "Miami, FL",
    propertyType: "Multi-family Residential",
    currentPrice: 8.32,
    priceChangePercent: -1.25,
    volume24h: 18750,
    marketCap: 4160000,
    annualYield: 7.8,
    totalSupply: 500000,
    availableSupply: 423400,
    daysListed: 86,
    priceHistory: generatePriceHistory(8.20, 0.03, 90),
    volumeHistory: generateVolumeData(90, 15000),
    propertyImage: "https://images.unsplash.com/photo-1460317442991-0ec209397118",
    propertyDescription: "Luxury residential complex on Miami's waterfront with high occupancy rates and premium amenities."
  },
  {
    id: "token3",
    propertyName: "Westfield Mall",
    tokenSymbol: "WFML",
    location: "Los Angeles, CA",
    propertyType: "Retail",
    currentPrice: 6.15,
    priceChangePercent: 0.85,
    volume24h: 14320,
    marketCap: 3075000,
    annualYield: 5.4,
    totalSupply: 500000,
    availableSupply: 482500,
    daysListed: 205,
    priceHistory: generatePriceHistory(5.80, 0.025, 90),
    volumeHistory: generateVolumeData(90, 12000),
    propertyImage: "https://images.unsplash.com/photo-1519567770908-fdf8e941df3f",
    propertyDescription: "Established shopping center in prime Los Angeles location with national anchor tenants."
  },
  {
    id: "token4",
    propertyName: "Innovation Campus",
    tokenSymbol: "INCM",
    location: "Austin, TX",
    propertyType: "Mixed-Use",
    currentPrice: 10.68,
    priceChangePercent: 4.32,
    volume24h: 25840,
    marketCap: 5340000,
    annualYield: 6.8,
    totalSupply: 500000,
    availableSupply: 428900,
    daysListed: 45,
    priceHistory: generatePriceHistory(9.20, 0.04, 90),
    volumeHistory: generateVolumeData(90, 20000),
    propertyImage: "https://images.unsplash.com/photo-1497366754035-f200968a6e72",
    propertyDescription: "Modern tech-focused campus with offices, co-working spaces, and retail in Austin's growing innovation district."
  },
  {
    id: "token5",
    propertyName: "Harbor Logistics Center",
    tokenSymbol: "HLCT",
    location: "Seattle, WA",
    propertyType: "Industrial",
    currentPrice: 12.24,
    priceChangePercent: 1.15,
    volume24h: 16780,
    marketCap: 6120000,
    annualYield: 7.2,
    totalSupply: 500000,
    availableSupply: 476500,
    daysListed: 154,
    priceHistory: generatePriceHistory(11.50, 0.02, 90),
    volumeHistory: generateVolumeData(90, 15000),
    propertyImage: "https://images.unsplash.com/photo-1553855426-34a5b0551452",
    propertyDescription: "Strategic logistics center near Seattle's port with long-term leases to major distribution companies."
  },
  {
    id: "token6",
    propertyName: "Greenhaven Apartments",
    tokenSymbol: "GHNV",
    location: "Chicago, IL",
    propertyType: "Multi-family Residential",
    currentPrice: 9.45,
    priceChangePercent: -0.65,
    volume24h: 12680,
    marketCap: 4725000,
    annualYield: 8.1,
    totalSupply: 500000,
    availableSupply: 456200,
    daysListed: 112,
    priceHistory: generatePriceHistory(9.30, 0.025, 90),
    volumeHistory: generateVolumeData(90, 10000),
    propertyImage: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267",
    propertyDescription: "Modern apartment complex in Chicago's growing South Loop district with strong rental demand."
  },
  {
    id: "token7",
    propertyName: "Golden Gate Offices",
    tokenSymbol: "GGOF",
    location: "San Francisco, CA",
    propertyType: "Commercial Office",
    currentPrice: 18.32,
    priceChangePercent: 3.25,
    volume24h: 35670,
    marketCap: 9160000,
    annualYield: 5.9,
    totalSupply: 500000,
    availableSupply: 442800,
    daysListed: 178,
    priceHistory: generatePriceHistory(16.20, 0.03, 90),
    volumeHistory: generateVolumeData(90, 30000),
    propertyImage: "https://images.unsplash.com/photo-1622126977176-bf766add5f48",
    propertyDescription: "Premium office property in San Francisco's financial district with tech and finance tenants."
  },
  {
    id: "token8",
    propertyName: "Wellness Medical Plaza",
    tokenSymbol: "WLMP",
    location: "Houston, TX",
    propertyType: "Healthcare",
    currentPrice: 15.65,
    priceChangePercent: 0.45,
    volume24h: 18920,
    marketCap: 7825000,
    annualYield: 6.5,
    totalSupply: 500000,
    availableSupply: 490300,
    daysListed: 28,
    priceHistory: generatePriceHistory(15.20, 0.02, 90),
    volumeHistory: generateVolumeData(90, 16000),
    propertyImage: "https://images.unsplash.com/photo-1629136572195-8cf4f0bbc822",
    propertyDescription: "State-of-the-art medical office building with long-term leases to leading healthcare providers."
  },
];

// Transaction types
export interface Transaction {
  id: string;
  tokenId: string;
  tokenSymbol: string;
  type: "buy" | "sell";
  price: number;
  quantity: number;
  total: number;
  status: "pending" | "completed" | "failed";
  timestamp: Date;
}

// Order types
export interface Order {
  tokenId: string;
  action: "buy" | "sell";
  quantity: number;
  price: number;
  total: number;
  type: "market" | "limit";
}
