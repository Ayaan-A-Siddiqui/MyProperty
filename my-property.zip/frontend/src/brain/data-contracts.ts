/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

export type CheckHealthData = HealthResponse;
