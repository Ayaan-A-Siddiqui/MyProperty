import { useState, useEffect } from "react";
import { WalletConnect } from "../components/WalletConnect";
import { NetworkStatus } from "../components/NetworkStatus";
import { TransactionStatus } from "../components/TransactionStatus";
import { TransactionConfirmation } from "../components/TransactionConfirmation";
import { Transaction, TransactionRequest, useWalletConnection } from "../utils/blockchain";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

/**
 * BlockchainDemo page demonstrates the Algorand blockchain integration
 */
export default function BlockchainDemo() {
  const { isConnected, selectedAccount, transactions } = useWalletConnection();
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [amount, setAmount] = useState(10);
  const [price, setPrice] = useState(25);
  const [transactionRequest, setTransactionRequest] = useState<TransactionRequest>({
    type: "buy",
    tokenId: "token1",
    tokenSymbol: "SKYT",
    amount: 10,
    price: 25,
  });
  
  // Update transaction request when inputs change
  useEffect(() => {
    setTransactionRequest(prev => ({
      ...prev,
      amount,
      price
    }));
  }, [amount, price]);
  
  // Handle buy transaction
  const handleBuy = () => {
    if (!isConnected || !selectedAccount) {
      toast.error("Please connect your wallet first");
      return;
    }
    
    setTransactionRequest(prev => ({
      ...prev,
      type: "buy"
    }));
    setIsConfirmOpen(true);
  };
  
  // Handle sell transaction
  const handleSell = () => {
    if (!isConnected || !selectedAccount) {
      toast.error("Please connect your wallet first");
      return;
    }
    
    // Check if user has enough tokens
    const token = selectedAccount.tokens.find(t => t.tokenId === transactionRequest.tokenId);
    if (!token || token.amount < amount) {
      toast.error(`You don't have enough ${transactionRequest.tokenSymbol} tokens`);
      return;
    }
    
    setTransactionRequest(prev => ({
      ...prev,
      type: "sell"
    }));
    setIsConfirmOpen(true);
  };
  
  // Handle successful transaction
  const handleSuccess = () => {
    toast.success(
      transactionRequest.type === "buy"
        ? `Successfully purchased ${amount} ${transactionRequest.tokenSymbol} tokens`
        : `Successfully sold ${amount} ${transactionRequest.tokenSymbol} tokens`
    );
  };
  
  return (
    <div className="container py-8 space-y-8">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Blockchain Demo</h1>
          <div className="flex items-center gap-4">
            <NetworkStatus />
            <WalletConnect />
          </div>
        </div>
        <p className="text-muted-foreground">
          This demo showcases the Algorand blockchain integration for property token transactions.
          Connect your wallet and try buying or selling tokens to see the transaction flow.
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Token Transaction</CardTitle>
              <CardDescription>
                Experience the simulated blockchain transaction flow for property tokens
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-3">
                  <div className="grid gap-2">
                    <Label htmlFor="token">Token</Label>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="px-4 py-1.5 text-sm font-medium">
                        SKYT
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        SkyTower Commercial Property
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="amount">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(parseInt(e.target.value))}
                      min={1}
                      max={1000}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="price">Price per token (USD)</Label>
                    <Input
                      id="price"
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(parseFloat(e.target.value))}
                      min={0.01}
                      step={0.01}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Total value:</span>
                      <span className="font-medium">
                        ${(amount * price).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between gap-2">
              <Button
                variant="outline"
                onClick={handleSell}
                disabled={!isConnected}
                className="w-full"
              >
                Sell Tokens
              </Button>
              <Button 
                onClick={handleBuy}
                disabled={!isConnected}
                className="w-full"
              >
                Buy Tokens
              </Button>
            </CardFooter>
          </Card>
          
          {isConnected && selectedAccount && (
            <Card>
              <CardHeader>
                <CardTitle>Your Wallet</CardTitle>
                <CardDescription>
                  {selectedAccount.name} ({selectedAccount.address.substring(0, 8)}...{selectedAccount.address.substring(selectedAccount.address.length - 8)})
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Balance</h3>
                    <div className="text-2xl font-bold">
                      {selectedAccount.balance.toFixed(2)} ALGO
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2">Property Tokens</h3>
                    {selectedAccount.tokens.length === 0 ? (
                      <div className="text-sm text-muted-foreground">
                        You don't own any property tokens yet
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {selectedAccount.tokens.map((token) => (
                          <div key={token.tokenId} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{token.tokenSymbol}</Badge>
                              <span className="text-sm">{token.amount} tokens</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              ${(token.amount * price).toFixed(2)} value
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>
                View your recent property token transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isConnected ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    Connect your wallet to view transaction history
                  </p>
                </div>
              ) : transactions.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">
                    No transactions found
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {transactions.slice(0, 5).map((transaction) => (
                    <div key={transaction.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="font-medium">
                            {transaction.type === "buy" && "Purchased"}
                            {transaction.type === "sell" && "Sold"}
                            {transaction.type === "transfer" && "Transferred"}
                            {transaction.type === "dividend" && "Dividend Payment"}
                            {" "}{transaction.amount} {transaction.tokenSymbol}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {transaction.timestamp.toLocaleDateString()} at {transaction.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                        <Badge variant={getVariantForTransactionType(transaction.type)}>
                          {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                        <span className="text-muted-foreground">Amount:</span>
                        <span>{transaction.amount} {transaction.tokenSymbol}</span>
                        
                        <span className="text-muted-foreground">Price:</span>
                        <span>${transaction.price.toFixed(2)} per token</span>
                        
                        <span className="text-muted-foreground">Total:</span>
                        <span>${transaction.total.toFixed(2)}</span>
                      </div>
                      
                      <Separator />
                      
                      <TransactionStatus transaction={transaction} showDetails={true} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Network Information</CardTitle>
              <CardDescription>
                Details about the Algorand blockchain network
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="about">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="about">About Algorand</TabsTrigger>
                  <TabsTrigger value="technical">Technical Details</TabsTrigger>
                </TabsList>
                <TabsContent value="about" className="space-y-4 pt-4">
                  <p className="text-sm text-muted-foreground">
                    Algorand is a high-performance blockchain that provides the security, scalability, and 
                    decentralization needed for property tokenization. The platform enables fractional 
                    ownership of real estate assets through secure and transparent token transactions.
                  </p>
                  
                  <div className="grid gap-2">
                    <h3 className="text-sm font-medium">Key Features</h3>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc pl-4">
                      <li>Fast transaction finality (under 5 seconds)</li>
                      <li>Low transaction fees</li>
                      <li>Environment-friendly pure proof-of-stake protocol</li>
                      <li>Smart contract capability for property transactions</li>
                      <li>Secure and transparent ownership records</li>
                    </ul>
                  </div>
                </TabsContent>
                <TabsContent value="technical" className="space-y-4 pt-4">
                  <div className="grid gap-4">
                    <div>
                      <h3 className="text-sm font-medium mb-1">Network Status</h3>
                      <NetworkStatus showDetails={true} className="mt-2" />
                    </div>
                    
                    <div className="grid gap-1">
                      <h3 className="text-sm font-medium">Technical Specifications</h3>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                        <span className="text-muted-foreground">Consensus:</span>
                        <span>Pure Proof-of-Stake</span>
                        
                        <span className="text-muted-foreground">Block time:</span>
                        <span>~4.5 seconds</span>
                        
                        <span className="text-muted-foreground">Transaction fee:</span>
                        <span>0.001 ALGO (minimum)</span>
                        
                        <span className="text-muted-foreground">Token standard:</span>
                        <span>Algorand Standard Asset (ASA)</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <TransactionConfirmation
        transaction={transactionRequest}
        isOpen={isConfirmOpen}
        onOpenChange={setIsConfirmOpen}
        onSuccess={handleSuccess}
      />
    </div>
  );
}

// Helper function to get badge variant based on transaction type
function getVariantForTransactionType(type: Transaction['type']): "default" | "outline" | "secondary" | "destructive" {
  switch (type) {
    case "buy":
      return "default";
    case "sell":
      return "secondary";
    case "transfer":
      return "outline";
    case "dividend":
      return "default";
    default:
      return "outline";
  }
}
