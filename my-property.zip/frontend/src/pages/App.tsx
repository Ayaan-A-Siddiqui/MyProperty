import React from "react";
import { Button } from "@/components/ui/button";
import { Header } from "components/Header";
import { InvestorBenefit, HowItWorksStep } from "utils/types";
import { sectionClasses, gradientText } from "utils/styles";

export default function App() {
  // Mock functions for login/register buttons
  const handleLogin = () => console.log("Login clicked");
  const handleRegister = () => console.log("Register clicked");

  // How it works steps
  const accreditedSteps: HowItWorksStep[] = [
    {
      title: "Submit Property",
      description: "Accredited investors submit commercial property details along with financial information for due diligence.",
      iconClass: "bg-blue-500/20 text-blue-500"
    },
    {
      title: "Due Diligence",
      description: "Our team performs thorough due diligence on the property and investor credentials to ensure compliance.",
      iconClass: "bg-emerald-500/20 text-emerald-500"
    },
    {
      title: "Set Investment",
      description: "Determine your investment amount while we tokenize the remaining value for fractional investors.",
      iconClass: "bg-amber-500/20 text-amber-500"
    },
    {
      title: "Receive Dividends",
      description: "Earn monthly dividends from your property investment alongside fractional investors.",
      iconClass: "bg-violet-500/20 text-violet-500"
    }
  ];

  const fractionalSteps: HowItWorksStep[] = [
    {
      title: "Browse Properties",
      description: "Explore tokenized commercial properties with detailed analytics and investment metrics.",
      iconClass: "bg-blue-500/20 text-blue-500"
    },
    {
      title: "Purchase Tokens",
      description: "Buy property tokens at your preferred price point with as little or as much as you want to invest.",
      iconClass: "bg-emerald-500/20 text-emerald-500"
    },
    {
      title: "Trade on Market",
      description: "Trade your tokens on our secondary market with real-time price data and insights.",
      iconClass: "bg-amber-500/20 text-amber-500"
    },
    {
      title: "Collect Dividends",
      description: "Earn proportional dividends from property revenue distributed directly through the blockchain.",
      iconClass: "bg-violet-500/20 text-violet-500"
    }
  ];

  // Benefits
  const accreditedBenefits: InvestorBenefit[] = [
    {
      title: "Efficient Capital Raising",
      description: "Quickly raise the capital you need beyond your initial investment through our network of fractional investors."
    },
    {
      title: "Reduced Barriers",
      description: "Access commercial properties that would otherwise be out of reach by leveraging fractional capital."
    },
    {
      title: "Liquidity Options",
      description: "Maintain the option to liquidate portions of your ownership through token sales when needed."
    },
    {
      title: "Transparent Process",
      description: "All transactions, ownership, and dividend distributions are recorded on the blockchain for complete transparency."
    }
  ];

  const fractionalBenefits: InvestorBenefit[] = [
    {
      title: "Access to Premium CRE",
      description: "Invest in high-quality commercial real estate previously only available to institutional investors."
    },
    {
      title: "Low Minimum Investment",
      description: "Start with as little as one token and build your portfolio at your own pace."
    },
    {
      title: "True Liquidity",
      description: "Sell your tokens on the secondary market without the lengthy holding periods of traditional real estate."
    },
    {
      title: "Global Opportunities",
      description: "Access real estate investments across the globe without geographical limitations."
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header onLogin={handleLogin} onRegister={handleRegister} />
      
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden">
        {/* Hexagonal grid background */}
        <div className="absolute inset-0 hexagon-grid opacity-10"></div>
        {/* Background accent */}
        <div className="absolute top-40 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-0 w-64 h-64 bg-blue-700/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">
              Commercial Real Estate<br />
              <span className={gradientText}>Reimagined Through Blockchain</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 md:mb-10">
              myproperty creates a secondary market for trading tokenized real estate securities, unlocking liquidity and accessibility for all investor types.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="px-8 py-6 text-lg">
                Get Started
              </Button>
              <Button size="lg" variant="outline" className="px-8 py-6 text-lg">
                Learn More
              </Button>
            </div>
            
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-bold">100+</div>
                <div className="text-sm text-muted-foreground">Properties Tokenized</div>
              </div>
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-bold">$250M+</div>
                <div className="text-sm text-muted-foreground">Trading Volume</div>
              </div>
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-bold">10,000+</div>
                <div className="text-sm text-muted-foreground">Investors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl md:text-3xl font-bold">8%</div>
                <div className="text-sm text-muted-foreground">Avg. Annual Dividend</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className={sectionClasses.base + " bg-secondary/20"}>
        <div className={sectionClasses.container}>
          <h2 className={sectionClasses.heading + " text-center"}>How myproperty Works</h2>
          <p className={sectionClasses.subheading + " text-center mx-auto"}>We've created a seamless platform that connects accredited investors with global fractional investors to democratize access to commercial real estate.</p>
          
          <div className="mt-16 space-y-16">
            {/* Accredited Investor Flow */}
            <div>
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-3"></span>
                For Accredited Investors
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {accreditedSteps.map((step, index) => (
                  <div key={index} className={sectionClasses.card + " h-full"}>
                    <div className="flex items-center mb-4">
                      <div className={`w-10 h-10 rounded flex items-center justify-center font-bold mr-3 ${step.iconClass}`}>
                        {index + 1}
                      </div>
                      <h4 className="font-bold">{step.title}</h4>
                    </div>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Fractional Investor Flow */}
            <div>
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-3"></span>
                For Fractional Investors
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {fractionalSteps.map((step, index) => (
                  <div key={index} className={sectionClasses.card + " h-full"}>
                    <div className="flex items-center mb-4">
                      <div className={`w-10 h-10 rounded flex items-center justify-center font-bold mr-3 ${step.iconClass}`}>
                        {index + 1}
                      </div>
                      <h4 className="font-bold">{step.title}</h4>
                    </div>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className={sectionClasses.base}>
        <div className={sectionClasses.container}>
          <h2 className={sectionClasses.heading + " text-center"}>Why Choose myproperty</h2>
          <p className={sectionClasses.subheading + " text-center mx-auto"}>Our blockchain-powered platform offers unique advantages for both accredited and fractional investors in commercial real estate.</p>
          
          <div className="mt-16 space-y-16">
            {/* Accredited Investor Benefits */}
            <div>
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-3"></span>
                Accredited Investor Benefits
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {accreditedBenefits.map((benefit, index) => (
                  <div key={index} className={sectionClasses.card + " gradient-border"}>
                    <h4 className="text-xl font-bold mb-3">{benefit.title}</h4>
                    <p className="text-muted-foreground">{benefit.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Fractional Investor Benefits */}
            <div>
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-3"></span>
                Fractional Investor Benefits
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {fractionalBenefits.map((benefit, index) => (
                  <div key={index} className={sectionClasses.card + " gradient-border"}>
                    <h4 className="text-xl font-bold mb-3">{benefit.title}</h4>
                    <p className="text-muted-foreground">{benefit.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        {/* Hexagonal grid background */}
        <div className="absolute inset-0 hexagon-grid opacity-10"></div>
        {/* Background accent */}
        <div className="absolute top-0 right-10 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Real Estate Investment Strategy?</h2>
            <p className="text-xl text-muted-foreground mb-10">Join myproperty today and gain access to our global marketplace of tokenized commercial real estate properties.</p>
            <Button size="lg" className="px-10 py-6 text-lg">
              Get Started Now
            </Button>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="border-t border-secondary/20 py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="relative w-8 h-8 mr-3">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-700 clip-path-hexagon"></div>
                <div className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm">P</div>
              </div>
              <p className="text-sm">© {new Date().getFullYear()} myproperty. All rights reserved.</p>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Terms</a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Privacy</a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Contact</a>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-6">myproperty is a digital platform for tokenized real estate investments. All investments involve risk and may lose value.</p>
        </div>
      </footer>
    </div>
  );
}
