import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Header } from "components/Header";
import { PropertyToken } from "components/PropertyToken";
import { TokenChart } from "components/TokenChart";
import { OrderForm } from "components/OrderForm";
import { mockTokens } from "utils/mockData";

export default function Marketplace() {
  const [selectedToken, setSelectedToken] = useState(mockTokens[0]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCriteria, setFilterCriteria] = useState("all");
  
  const filteredTokens = mockTokens.filter(token => {
    const matchesSearch = token.propertyName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         token.tokenSymbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         token.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterCriteria === "all") return matchesSearch;
    if (filterCriteria === "high-yield" && token.annualYield >= 7) return matchesSearch;
    if (filterCriteria === "trending" && token.volume24h > 15000) return matchesSearch;
    if (filterCriteria === "new" && token.daysListed < 30) return matchesSearch;
    
    return false;
  });

  const handleSelectToken = (token) => {
    setSelectedToken(token);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Token Marketplace</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left column: Token listings */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Available Tokens</CardTitle>
                <CardDescription>Browse property tokens available for trading</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Input 
                        placeholder="Search tokens..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <Select value={filterCriteria} onValueChange={setFilterCriteria}>
                      <SelectTrigger className="w-[160px]">
                        <SelectValue placeholder="Filter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Tokens</SelectItem>
                        <SelectItem value="high-yield">High Yield (7%+)</SelectItem>
                        <SelectItem value="trending">Trending</SelectItem>
                        <SelectItem value="new">Newly Listed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                    {filteredTokens.map((token) => (
                      <PropertyToken 
                        key={token.id}
                        token={token}
                        isSelected={selectedToken.id === token.id}
                        onSelect={() => handleSelectToken(token)}
                      />
                    ))}
                    
                    {filteredTokens.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        No tokens match your search criteria
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Right column: Selected token details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Token info card */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex justify-between">
                  <div>
                    <CardTitle>{selectedToken.propertyName}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <span className="text-sm font-medium mr-2">{selectedToken.tokenSymbol}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-500">
                        {selectedToken.location}
                      </span>
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">${selectedToken.currentPrice.toFixed(2)}</div>
                    <div className={`text-sm ${selectedToken.priceChangePercent >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                      {selectedToken.priceChangePercent >= 0 ? '+' : ''}{selectedToken.priceChangePercent.toFixed(2)}%
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <div className="text-sm text-muted-foreground">24h Volume</div>
                    <div className="font-medium">${selectedToken.volume24h.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Market Cap</div>
                    <div className="font-medium">${selectedToken.marketCap.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Annual Yield</div>
                    <div className="font-medium">{selectedToken.annualYield}%</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Available Supply</div>
                    <div className="font-medium">{selectedToken.availableSupply.toLocaleString()} / {selectedToken.totalSupply.toLocaleString()}</div>
                  </div>
                </div>
                
                <TokenChart tokenData={selectedToken} />
              </CardContent>
            </Card>
            
            {/* Trade form */}
            <Card>
              <CardHeader>
                <CardTitle>Trade {selectedToken.tokenSymbol}</CardTitle>
                <CardDescription>Place buy or sell orders at your preferred price</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="buy">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="buy">Buy</TabsTrigger>
                    <TabsTrigger value="sell">Sell</TabsTrigger>
                  </TabsList>
                  <TabsContent value="buy">
                    <OrderForm 
                      action="buy" 
                      token={selectedToken} 
                    />
                  </TabsContent>
                  <TabsContent value="sell">
                    <OrderForm 
                      action="sell" 
                      token={selectedToken} 
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}