import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

export interface Props {
  onLogin?: () => void;
  onRegister?: () => void;
}

export const Header = ({ onLogin, onRegister }: Props) => {
  const navigate = useNavigate();
  
  return (
    <header className="border-b border-secondary/20 backdrop-blur-sm bg-background/80 sticky top-0 z-30 py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <div 
            className="relative h-10 mr-3 cursor-pointer flex items-center" 
            onClick={() => navigate("/")}
          >
            <svg width="40" height="40" viewBox="0 0 40 40" className="mr-1">
              <rect width="40" height="40" fill="transparent" />
              <text x="2" y="25" fill="#3b82f6" fontFamily="Arial" fontSize="24" fontWeight="bold">M</text>
              <text x="20" y="25" fill="#ffffff" fontFamily="Arial" fontSize="24" fontWeight="bold">P</text>
            </svg>
            <h1 className="text-xl font-bold cursor-pointer flex">
              <span className="text-blue-500">My</span><span>Property</span>
            </h1>
          </div>
        </div>
        
        <nav className="flex items-center space-x-6">
          <div className="hidden md:flex items-center space-x-6">
            <Button 
              variant="link" 
              className="text-muted-foreground hover:text-foreground" 
              onClick={() => navigate("/marketplace")}
            >
              Marketplace
            </Button>
            <Button 
              variant="link" 
              className="text-muted-foreground hover:text-foreground"
              onClick={() => navigate("/")}  
            >
              How It Works
            </Button>
            <Button 
              variant="link" 
              className="text-muted-foreground hover:text-foreground"
              onClick={() => navigate("/")} 
            >
              Benefits
            </Button>
          </div>
          
          <div className="hidden sm:flex items-center gap-2 bg-secondary/50 px-3 py-1.5 rounded-lg mx-2">
            <div className="size-2 bg-emerald-400 rounded-full animate-pulse"></div>
            <span className="text-xs font-medium">Algorand</span>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" onClick={onLogin || (() => navigate("/login"))}>Log In</Button>
            <Button onClick={onRegister || (() => navigate("/register"))}>Register</Button>
          </div>
        </nav>
      </div>
    </header>
  );
};
