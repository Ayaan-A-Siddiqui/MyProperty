import { useNetworkStatus } from "../utils/blockchain";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface Props {
  /** Whether to show extended details */
  showDetails?: boolean;
  /** CSS class name */
  className?: string;
}

/**
 * NetworkStatus component displays the current status of the Algorand blockchain
 */
export function NetworkStatus({ showDetails = false, className = "" }: Props) {
  const { status, isLoading } = useNetworkStatus();
  
  if (isLoading) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <div className="h-2 w-2 rounded-full bg-gray-400 animate-pulse"></div>
        <span className="text-xs text-muted-foreground">Connecting...</span>
      </div>
    );
  }
  
  if (!status) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <div className="h-2 w-2 rounded-full bg-red-500"></div>
        <span className="text-xs text-muted-foreground">Network unavailable</span>
      </div>
    );
  }
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`flex items-center gap-2 cursor-help ${className}`}>
            <div 
              className={`h-2 w-2 rounded-full ${status.connected ? 'bg-green-500' : 'bg-red-500'}`}
            ></div>
            <span className="text-xs text-muted-foreground">
              Algorand {status.connected ? 'Online' : 'Offline'}
            </span>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" align="start" className="max-w-[300px]">
          <div className="space-y-2 p-1">
            <div className="font-medium">Algorand Network Status</div>
            <div className="text-xs grid grid-cols-2 gap-x-4 gap-y-1">
              <span className="text-muted-foreground">Status:</span>
              <span className="">{status.status}</span>
              
              <span className="text-muted-foreground">Round:</span>
              <span className="">{status.currentRound.toLocaleString()}</span>
              
              <span className="text-muted-foreground">TPS:</span>
              <span className="">{status.tps}</span>
              
              {showDetails && (
                <>
                  <span className="text-muted-foreground">Last checked:</span>
                  <span className="">{new Date().toLocaleTimeString()}</span>
                </>
              )}
            </div>
            
            <div className="text-xs text-muted-foreground pt-1">
              {status.connected ? (
                "The network is operating normally"
              ) : (
                "The network is currently experiencing issues"
              )}
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
