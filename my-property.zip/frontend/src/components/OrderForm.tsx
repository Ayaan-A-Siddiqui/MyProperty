import React, { useState, useEffect } from "react";
import { Token } from "utils/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";

interface OrderFormProps {
  action: "buy" | "sell";
  token: Token;
}

export const OrderForm: React.FC<OrderFormProps> = ({ action, token }) => {
  const [orderType, setOrderType] = useState<"market" | "limit">("market");
  const [quantity, setQuantity] = useState<number>(10);
  const [price, setPrice] = useState<number>(token.currentPrice);
  const [total, setTotal] = useState<number>(0);
  const [balance, setBalance] = useState<number>(action === "buy" ? 5000 : 100);
  const [available, setAvailable] = useState<number>(action === "buy" ? balance : 100);
  
  // Update price when token changes
  useEffect(() => {
    setPrice(token.currentPrice);
  }, [token]);
  
  // Calculate total cost
  useEffect(() => {
    setTotal(quantity * price);
  }, [quantity, price]);
  
  // Simulate balance reset when action changes
  useEffect(() => {
    setBalance(action === "buy" ? 5000 : 100);
    setAvailable(action === "buy" ? 5000 : 100);
    setQuantity(10);
  }, [action]);
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 0) return;
    
    // Limit quantity based on available balance
    if (action === "buy") {
      const maxQuantity = Math.floor(balance / price);
      setQuantity(Math.min(value, maxQuantity));
    } else {
      setQuantity(Math.min(value, balance));
    }
  };
  
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (isNaN(value) || value <= 0) return;
    setPrice(value);
  };
  
  const handleSliderChange = (values: number[]) => {
    const percentage = values[0];
    if (action === "buy") {
      const maxQuantity = Math.floor(balance / price);
      setQuantity(Math.floor(maxQuantity * (percentage / 100)));
    } else {
      setQuantity(Math.floor(available * (percentage / 100)));
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (quantity <= 0) {
      toast.error("Please enter a valid quantity");
      return;
    }
    
    if (action === "buy" && total > balance) {
      toast.error("Insufficient funds");
      return;
    }
    
    if (action === "sell" && quantity > available) {
      toast.error("Insufficient tokens");
      return;
    }
    
    // Simulate order placement
    toast.success(
      <div className="space-y-1">
        <p className="font-medium">{action === "buy" ? "Buy" : "Sell"} Order Placed</p>
        <p className="text-sm text-muted-foreground">
          {quantity} {token.tokenSymbol} @ ${price.toFixed(2)}
        </p>
      </div>
    );
    
    // Reset form
    if (action === "buy") {
      setBalance(prev => prev - total);
    } else {
      setAvailable(prev => prev - quantity);
    }
    
    setQuantity(0);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4 py-2">
      <div className="space-y-2">
        <Label>Order Type</Label>
        <RadioGroup 
          value={orderType} 
          onValueChange={(value) => setOrderType(value as "market" | "limit")}
          className="flex gap-4"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="market" id="market" />
            <Label htmlFor="market" className="cursor-pointer">Market</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="limit" id="limit" />
            <Label htmlFor="limit" className="cursor-pointer">Limit</Label>
          </div>
        </RadioGroup>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between">
          <Label htmlFor="quantity">Quantity</Label>
          <span className="text-xs text-muted-foreground">
            Available: {action === "buy" ? `$${balance.toFixed(2)}` : `${available} tokens`}
          </span>
        </div>
        <div className="flex space-x-2">
          <Input 
            id="quantity" 
            type="number" 
            value={quantity}
            onChange={handleQuantityChange}
            min={0}
            className="flex-1"
          />
          <div className="px-3 py-2 bg-secondary rounded flex items-center">
            <span className="text-sm font-medium">{token.tokenSymbol}</span>
          </div>
        </div>
      </div>
      
      <div>
        <Slider 
          value={[quantity === 0 ? 0 : (action === "buy" ? 
            (quantity / Math.floor(balance / price)) * 100 : 
            (quantity / available) * 100)]}
          onValueChange={handleSliderChange}
          max={100}
          step={1}
          className="py-4"
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>0%</span>
          <span>25%</span>
          <span>50%</span>
          <span>75%</span>
          <span>100%</span>
        </div>
      </div>
      
      {orderType === "limit" && (
        <div className="space-y-2">
          <Label htmlFor="price">Price</Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
            <Input 
              id="price" 
              type="number" 
              value={price}
              onChange={handlePriceChange}
              className="pl-7"
              min={0.01}
              step={0.01}
            />
          </div>
          <div className="text-xs">
            <span className="text-muted-foreground">Current price:</span> <span className="font-medium">${token.currentPrice.toFixed(2)}</span>
          </div>
        </div>
      )}
      
      <div className="space-y-2 pt-2">
        <div className="flex justify-between items-center text-sm">
          <span>Estimated Total</span>
          <span className="font-medium">${total.toFixed(2)}</span>
        </div>
        <div className="text-xs text-muted-foreground">
          {action === "buy" ? "Includes 0.5% transaction fee" : "After 0.5% transaction fee"}
        </div>
      </div>
      
      <Button 
        type="submit" 
        className="w-full py-6" 
        disabled={quantity <= 0 || (action === "buy" && total > balance) || (action === "sell" && quantity > available)}
      >
        {action === "buy" ? "Buy" : "Sell"} {token.tokenSymbol}
      </Button>
    </form>
  );
};