import React from "react";
import { Token } from "utils/mockData";

interface PropertyTokenProps {
  token: Token;
  isSelected: boolean;
  onSelect: () => void;
}

export const PropertyToken: React.FC<PropertyTokenProps> = ({ token, isSelected, onSelect }) => {
  return (
    <div 
      className={`p-3 rounded-lg cursor-pointer transition-colors ${isSelected ? 'bg-accent' : 'hover:bg-accent/50'}`}
      onClick={onSelect}
    >
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded overflow-hidden flex-shrink-0">
          <img 
            src={token.propertyImage} 
            alt={token.propertyName} 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start">
            <div className="truncate font-medium">{token.propertyName}</div>
            <div className="text-right">
              <div className="font-semibold">${token.currentPrice.toFixed(2)}</div>
              <div className={`text-xs ${token.priceChangePercent >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                {token.priceChangePercent >= 0 ? '+' : ''}{token.priceChangePercent.toFixed(2)}%
              </div>
            </div>
          </div>
          
          <div className="flex justify-between mt-1 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="font-medium">{token.tokenSymbol}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-blue-500/10 text-blue-500 text-[10px]">
                {token.propertyType}
              </span>
            </div>
            <div>
              {token.annualYield}% yield
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};