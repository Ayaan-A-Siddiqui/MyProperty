import { Transaction } from "../utils/blockchain";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface Props {
  transaction: Transaction;
  showDetails?: boolean;
  className?: string;
}

/**
 * TransactionStatus component displays the status and confirmation progress of a blockchain transaction
 */
export function TransactionStatus({ transaction, showDetails = false, className = "" }: Props) {
  const { status, confirmations } = transaction;
  
  // Calculate confirmation progress (max 200 confirmations for UI purposes)
  const progress = status === "confirmed" ? Math.min((confirmations / 200) * 100, 100) : 0;
  
  // Format transaction hash for display
  const formatTransactionId = (id: string) => {
    if (id.length < 16) return id;
    return `${id.substring(0, 8)}...${id.substring(id.length - 8)}`;
  };
  
  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {status === "pending" && (
            <Badge variant="outline" className="text-yellow-500 border-yellow-500">
              Pending
            </Badge>
          )}
          
          {status === "confirmed" && (
            <Badge variant="outline" className="text-green-500 border-green-500">
              Confirmed{confirmations >= 200 ? " (Final)" : ""}
            </Badge>
          )}
          
          {status === "failed" && (
            <Badge variant="outline" className="text-red-500 border-red-500">
              Failed
            </Badge>
          )}
          
          {status === "confirmed" && confirmations > 0 && confirmations < 200 && (
            <span className="text-xs text-muted-foreground">
              {confirmations} confirmation{confirmations !== 1 ? "s" : ""}
            </span>
          )}
        </div>
        
        {showDetails && transaction.blockNumber && (
          <span className="text-xs text-muted-foreground">
            Block #{transaction.blockNumber}
          </span>
        )}
      </div>
      
      {status === "confirmed" && confirmations < 200 && (
        <Progress value={progress} className="h-1" />
      )}
      
      {showDetails && (
        <div className="text-xs text-muted-foreground space-y-1 pt-1">
          <div className="flex items-center justify-between">
            <span>Transaction ID:</span>
            <span className="font-mono">{formatTransactionId(transaction.id)}</span>
          </div>
          
          {transaction.fee > 0 && (
            <div className="flex items-center justify-between">
              <span>Network Fee:</span>
              <span>{transaction.fee.toFixed(4)} ALGO</span>
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <span>Timestamp:</span>
            <span>{transaction.timestamp.toLocaleString()}</span>
          </div>
        </div>
      )}
    </div>
  );
}
