import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TransactionRequest, useWalletConnection } from "../utils/blockchain";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";

interface Props {
  /** The transaction to confirm */
  transaction: TransactionRequest;
  /** Whether the dialog is open */
  isOpen: boolean;
  /** Callback when dialog open state changes */
  onOpenChange: (open: boolean) => void;
  /** Callback when transaction is confirmed successfully */
  onSuccess?: () => void;
  /** Callback when transaction fails */
  onError?: () => void;
}

/**
 * TransactionConfirmation component for confirming blockchain transactions
 */
export function TransactionConfirmation({ 
  transaction, 
  isOpen, 
  onOpenChange,
  onSuccess,
  onError 
}: Props) {
  const { submitTransaction, selectedAccount } = useWalletConnection();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [stage, setStage] = useState<'review' | 'submitting' | 'confirming'>('review');
  
  // Format currency value for display
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };
  
  // Reset dialog state when closed
  const handleOpenChange = (open: boolean) => {
    if (!open && !isSubmitting) {
      setTimeout(() => {
        setStage('review');
      }, 300);
    }
    onOpenChange(open);
  };
  
  // Handle transaction submission
  const handleSubmit = async () => {
    if (!selectedAccount) return;
    
    setIsSubmitting(true);
    setStage('submitting');
    
    try {
      // Simulate wallet transaction signing
      await new Promise(resolve => setTimeout(resolve, 1500));
      setStage('confirming');
      
      // Submit transaction to blockchain
      const result = await submitTransaction(transaction);
      
      if (result && result.status === 'confirmed') {
        onSuccess?.();
      } else {
        onError?.();
      }
    } catch (error) {
      console.error('Transaction error:', error);
      onError?.();
    } finally {
      setIsSubmitting(false);
      handleOpenChange(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {stage === 'review' && 'Confirm Transaction'}
            {stage === 'submitting' && 'Signing Transaction'}
            {stage === 'confirming' && 'Confirming Transaction'}
          </DialogTitle>
          <DialogDescription>
            {stage === 'review' && 'Review and confirm your transaction details before proceeding'}
            {stage === 'submitting' && 'Please confirm this transaction in your wallet'}
            {stage === 'confirming' && 'Submitting your transaction to the Algorand blockchain'}
          </DialogDescription>
        </DialogHeader>
        
        {stage === 'review' && (
          <div className="space-y-4">
            <div className="grid gap-2">
              <h3 className="text-sm font-medium leading-none">
                {transaction.type === 'buy' ? 'Purchase' : 'Sale'} Details
              </h3>
              <Separator />
              
              <div className="grid grid-cols-2 gap-1 text-sm">
                <span className="text-muted-foreground">Type:</span>
                <span className="font-medium">
                  {transaction.type === 'buy' ? 'Buy' : transaction.type === 'sell' ? 'Sell' : 'Transfer'}
                </span>
                
                <span className="text-muted-foreground">Token:</span>
                <span className="font-medium">{transaction.tokenSymbol}</span>
                
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium">{transaction.amount} tokens</span>
                
                <span className="text-muted-foreground">Price per token:</span>
                <span className="font-medium">{formatCurrency(transaction.price)}</span>
                
                <span className="text-muted-foreground">Total:</span>
                <span className="font-medium">{formatCurrency(transaction.price * transaction.amount)}</span>
              </div>
            </div>
            
            <div className="grid gap-2">
              <h3 className="text-sm font-medium leading-none">Wallet</h3>
              <Separator />
              
              <div className="grid grid-cols-2 gap-1 text-sm">
                <span className="text-muted-foreground">Account:</span>
                <span className="font-medium">{selectedAccount?.name || 'Not connected'}</span>
                
                <span className="text-muted-foreground">Address:</span>
                <span className="font-mono text-xs truncate">{selectedAccount?.address || 'N/A'}</span>
                
                <span className="text-muted-foreground">Balance:</span>
                <span className="font-medium">{selectedAccount ? `${selectedAccount.balance.toFixed(2)} ALGO` : 'N/A'}</span>
              </div>
            </div>
            
            <div className="rounded-md bg-amber-50 dark:bg-amber-950/30 p-3 text-amber-900 dark:text-amber-200 text-sm">
              <p>Once submitted, this transaction cannot be reversed. Property token transactions are subject to network confirmation times and fees.</p>
            </div>
          </div>
        )}
        
        {(stage === 'submitting' || stage === 'confirming') && (
          <div className="flex flex-col items-center justify-center py-6 space-y-4">
            <div className="relative">
              <Loader2 className="h-16 w-16 animate-spin text-primary" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-8 w-8 rounded-full bg-background"></div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="font-medium">
                {stage === 'submitting' && 'Waiting for confirmation...'}
                {stage === 'confirming' && 'Submitting to blockchain...'}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {stage === 'submitting' && 'Please approve this transaction in your wallet application'}
                {stage === 'confirming' && 'Your transaction is being processed by the Algorand network'}
              </p>
            </div>
          </div>
        )}
        
        <DialogFooter>
          {stage === 'review' && (
            <>
              <Button variant="outline" onClick={() => handleOpenChange(false)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isSubmitting || !selectedAccount}>
                Confirm Transaction
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
