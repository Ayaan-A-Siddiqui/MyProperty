import React, { useState } from "react";
import { Token } from "utils/mockData";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TokenChartProps {
  tokenData: Token;
}

export const TokenChart: React.FC<TokenChartProps> = ({ tokenData }) => {
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "90d">("30d");
  
  const getPriceData = () => {
    const history = [...tokenData.priceHistory];
    let filteredData;
    
    if (timeRange === "7d") {
      filteredData = history.slice(-8);
    } else if (timeRange === "30d") {
      filteredData = history.slice(-31);
    } else {
      filteredData = history;
    }
    
    return filteredData;
  };
  
  const getVolumeData = () => {
    const history = [...tokenData.volumeHistory];
    let filteredData;
    
    if (timeRange === "7d") {
      filteredData = history.slice(-8);
    } else if (timeRange === "30d") {
      filteredData = history.slice(-31);
    } else {
      filteredData = history;
    }
    
    return filteredData;
  };
  
  const priceData = getPriceData();
  const volumeData = getVolumeData();
  
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-md shadow-md p-2 text-xs">
          <p className="font-medium">{label}</p>
          {payload[0] && (
            <p className="text-emerald-500">
              Price: ${payload[0].value.toFixed(2)}
            </p>
          )}
          {payload[1] && (
            <p className="text-blue-500">
              Volume: ${payload[1].value.toLocaleString()}
            </p>
          )}
        </div>
      );
    }
    return null;
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-medium">Token Performance</h3>
        <div className="flex space-x-1 text-xs">
          <button 
            className={`px-2 py-1 rounded ${timeRange === "7d" ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'}`}
            onClick={() => setTimeRange("7d")}
          >
            7D
          </button>
          <button 
            className={`px-2 py-1 rounded ${timeRange === "30d" ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'}`}
            onClick={() => setTimeRange("30d")}
          >
            30D
          </button>
          <button 
            className={`px-2 py-1 rounded ${timeRange === "90d" ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'}`}
            onClick={() => setTimeRange("90d")}
          >
            90D
          </button>
        </div>
      </div>
      
      <Tabs defaultValue="price">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="price">Price History</TabsTrigger>
          <TabsTrigger value="volume">Trading Volume</TabsTrigger>
        </TabsList>
        
        <TabsContent value="price" className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={priceData}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return `${date.getMonth() + 1}/${date.getDate()}`;
                }} 
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                domain={[(dataMin: number) => dataMin * 0.95, (dataMax: number) => dataMax * 1.05]} 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `$${value.toFixed(2)}`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke="#10b981" 
                strokeWidth={2} 
                dot={false} 
                activeDot={{ r: 4 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>
        
        <TabsContent value="volume" className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={volumeData}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis 
                dataKey="date" 
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return `${date.getMonth() + 1}/${date.getDate()}`;
                }} 
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="volume" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>
      </Tabs>
      
      <div className="bg-secondary/20 p-3 rounded-md mt-4">
        <h4 className="text-sm font-medium mb-1">Analyst Recommendation</h4>
        <p className="text-xs text-muted-foreground">
          {tokenData.annualYield > 7 
            ? "High yield property with strong income potential. Consider acquiring for stable returns." 
            : tokenData.priceChangePercent > 3
              ? "Momentum trend detected with significant price appreciation. Good candidate for short-term position."
              : "This property shows stable performance and moderate yield, suitable for balanced portfolios."}
        </p>
      </div>
    </div>
  );
};