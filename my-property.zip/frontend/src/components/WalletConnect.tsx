import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { WalletType, useWalletConnection } from "../utils/blockchain";
import { Badge } from "@/components/ui/badge";
import { Radio, RadioGroup } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface Props {
  /** Button variant for the connect button */
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive";
  /** Size of the connect button */
  size?: "default" | "sm" | "lg" | "icon";
  /** Whether to show connect dialog or expand the wallet UI inline */
  inline?: boolean;
  /** Class name for the connect button */
  className?: string;
}

/**
 * WalletConnect component for connecting to Algorand wallets
 */
export function WalletConnect({ variant = "default", size = "default", inline = false, className = "" }: Props) {
  const { isConnecting, isConnected, selectedAccount, connect, disconnect } = useWalletConnection();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState<WalletType>("algorand");

  const handleConnect = async () => {
    await connect(selectedWallet);
    setIsDialogOpen(false);
  };

  const handleOpenDialog = () => {
    if (!isConnected) {
      setIsDialogOpen(true);
    }
  };

  if (isConnected && selectedAccount) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <div className="hidden sm:block">
          <Badge variant="outline" className="font-mono text-xs">
            {selectedAccount.address.substring(0, 8)}...{selectedAccount.address.substring(selectedAccount.address.length - 8)}
          </Badge>
        </div>
        <Button
          size={size}
          variant={variant}
          onClick={disconnect}
          className="gap-2"
        >
          <div className="flex flex-col items-start">
            <span>{selectedAccount.name}</span>
            <span className="text-xs opacity-80">{selectedAccount.balance.toFixed(2)} ALGO</span>
          </div>
          <span className="sr-only">Disconnect wallet</span>
        </Button>
      </div>
    );
  }

  if (inline) {
    return (
      <div className={`space-y-4 ${className}`}>
        <h3 className="text-lg font-semibold">Connect Your Wallet</h3>
        <RadioGroup value={selectedWallet} onValueChange={(value) => setSelectedWallet(value as WalletType)}>
          <div className="flex items-start space-x-6">
            <div className="flex items-center space-x-2">
              <Radio id="algo" value="algorand" />
              <Label htmlFor="algo">Algorand Wallet</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Radio id="pera" value="pera" />
              <Label htmlFor="pera">Pera Wallet</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Radio id="myalgo" value="myalgo" />
              <Label htmlFor="myalgo">MyAlgo Wallet</Label>
            </div>
          </div>
        </RadioGroup>
        <Button
          size={size}
          variant={variant}
          onClick={handleConnect}
          disabled={isConnecting}
          className="w-full md:w-auto"
        >
          {isConnecting ? "Connecting..." : "Connect Wallet"}
        </Button>
      </div>
    );
  }

  return (
    <>
      <Button
        size={size}
        variant={variant}
        onClick={handleOpenDialog}
        disabled={isConnecting}
        className={className}
      >
        {isConnecting ? "Connecting..." : "Connect Wallet"}
      </Button>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Connect Wallet</DialogTitle>
            <DialogDescription>
              Connect your Algorand wallet to start trading property tokens
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <RadioGroup
              value={selectedWallet}
              onValueChange={(value) => setSelectedWallet(value as WalletType)}
              className="grid grid-cols-3 gap-4"
            >
              <div className="flex flex-col items-center gap-2 rounded-md border p-4 hover:bg-accent cursor-pointer">
                <Radio id="algo-dialog" value="algorand" className="sr-only" />
                <Label htmlFor="algo-dialog" className="cursor-pointer">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-white flex items-center justify-center text-xl font-bold">
                    A
                  </div>
                  <span className="mt-2 block text-center">Algorand</span>
                </Label>
              </div>

              <div className="flex flex-col items-center gap-2 rounded-md border p-4 hover:bg-accent cursor-pointer">
                <Radio id="pera-dialog" value="pera" className="sr-only" />
                <Label htmlFor="pera-dialog" className="cursor-pointer">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 text-white flex items-center justify-center text-xl font-bold">
                    P
                  </div>
                  <span className="mt-2 block text-center">Pera</span>
                </Label>
              </div>

              <div className="flex flex-col items-center gap-2 rounded-md border p-4 hover:bg-accent cursor-pointer">
                <Radio id="myalgo-dialog" value="myalgo" className="sr-only" />
                <Label htmlFor="myalgo-dialog" className="cursor-pointer">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 text-white flex items-center justify-center text-xl font-bold">
                    M
                  </div>
                  <span className="mt-2 block text-center">MyAlgo</span>
                </Label>
              </div>
            </RadioGroup>
          </div>
          <DialogFooter>
            <Button
              onClick={handleConnect}
              disabled={isConnecting}
              className="w-full"
            >
              {isConnecting ? "Connecting..." : "Connect Wallet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
